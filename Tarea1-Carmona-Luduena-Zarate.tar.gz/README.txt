Para compilar escriba en la consola 
	make compi

Situe el caso de prueba en la misma carpeta que espias.cpp

Para ejecutrar escriba: ./tarea1 < nombredelarchivo.txt